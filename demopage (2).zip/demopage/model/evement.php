<?php
//Je créer ma classe personnage dont le nommage par convention fera reference à l'entité SQL sur laquelle de modéle repose 
class evement extends database
{
    //Je déclare les attributs de mon modéle qui feront reference aux propriétés de L'entité SQL concerné 
    public $id = 0;
    public $surname = "";
    public $pays = 0;
    public $ville = "";
    //public $color = "";

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Method qui retourne un TOKEN 
     * @return HASH
     */
    public function generateCSRFToken()
    {
        $length = 10;
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ%=';
        $character = strlen($characters);
        $token = '';
        for ($i = 0; $i < $length; $i++) {
            $token .= $characters[mt_rand(0, $character - 1)];
        }
        return $token;
    }

    /**
     * Method qui permet d'inseret un personnage en base de donnée
     *  @return bool
     */
    public function createEvement()
    {
        $req = 'INSERT INTO `envement`(`surname`, `pays`, `ville`) VALUES (:surname , :pays , :ville );';
        $insertPersonnage = $this->db->prepare($req);
        $insertPersonnage->bindValue(':surname', $this->surname, PDO::PARAM_STR);
        $insertPersonnage->bindValue(':pays', $this->pays, PDO::PARAM_INT);
        $insertPersonnage->bindValue(':ville', $this->ville, PDO::PARAM_STR);
        //$insertPersonnage->bindValue(':color', $this->color, PDO::PARAM_STR);
        return $insertPersonnage->execute();
    }

    /**
     * Method qui permet de recuperer la liste des personnages
     * @return type SELECT
     */
    public function getAllEvement()
    {
        $query = 'SELECT * FROM `evement`;';
        //Ma Query execute ma requete SQL
        $perso = $this->db->query($query);
        //FetchAll Retourne le resultat de l'execution de ma erquete
        return $perso->fetchAll(PDO::FETCH_OBJ);
    }


    /**
     * Method qui permet d'afficher un personnage ainsi que ses caractéritisques
     * @return bool
     */
    public function getEvementById()
    {
        $query = 'SELECT * FROM `evement` WHERE `id`=:id ;';
        $find = $this->db->prepare($query);
        $find->bindValue(':id', $this->id, PDO::PARAM_INT);
        if ($find->execute()) {
            return $find->fetch(PDO::FETCH_OBJ);
        }
    }


    /**
     * Method  Qui permet de modifier un personnage
     * @return bool
     */
    public function updateEvement()
    {
        $req = 'UPDATE `evement` SET `surname`=:surname , `pays`=:pays , `ville`=:ville  WHERE `id`=:id;';
        $personnage = $this->db->prepare($req);
        $personnage->bindValue(':surname', $this->surname, PDO::PARAM_STR);
        $personnage->bindValue(':pays', $this->pays, PDO::PARAM_INT);
        $personnage->bindValue(':ville', $this->ville, PDO::PARAM_STR);
       //$personnage->bindValue(':color', $this->color, PDO::PARAM_STR);
        $personnage->bindValue(':id', $this->id, PDO::PARAM_INT);
        return $personnage->execute();
    }

    /**
     * Method qui permet d'effacer un personnage
     * @return type DELETE
     */
    public function deleteEvement()
    {
        $query = 'DELETE FROM `evement` WHERE `id`=:id;';
        $article = $this->db->prepare($query);
        $article->bindValue(':id', $this->id, PDO::PARAM_INT);
        return $article->execute();
    }

    public function isAVille($name)
    {
        if ($this->pays!= 0) {
            echo "evement" . $name->surname . " est vivant ";
        } else {
            echo "evement " . $name->surname . " est mort ";
        }
    }

    public function superPays($cible)
    {
        return $cible->ville = 10;
    }

    public function Pays($cible)
    {
        return $cible->ville = 50;
    }

    public function deadPays($cible)
    {
        $req = 'UPDATE `evement` SET `ville`=:ville  WHERE `id`=:id;';
        $personnage = $this->db->prepare($req);
        $personnage->bindValue(':pays', $this->ville = 0, PDO::PARAM_STR);
        $personnage->bindValue(':id', $this->id, PDO::PARAM_INT);
        return $personnage->execute();
    }

    public function regenere($cible)
    {
        $req = 'UPDATE `evements` SET `ville`=:ville  WHERE `id`=:id;';
        $personnage = $this->db->prepare($req);
        $personnage->bindValue(':ville', $this->ville = 100, PDO::PARAM_STR);
        $personnage->bindValue(':id', $this->id, PDO::PARAM_INT);
        return $personnage->execute();
    }
    public function courrir()
    {
        echo $this->surname . ' est en train de courrir ';
    }
    public function marcher()
    {
        echo $this->surname . ' est en train de marcher ';
    }
}
