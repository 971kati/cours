<h3 class="text-center mt-5">Connexion</h3>
<hr />
<div id="elem"></div>
<form action="" id="form">
    <div class="form-group">
        <label for="email">Adresse email :</label>
        <input type="email" class="form-control" id="email" />
    </div>
    <div class="form-group">
        <label for="password">Mot de passe :</label>
        <input type="password" class="form-control" id="password" />
    </div>
    <div class="form-group">
        <label for="password">Mot de passe :</label>
        <input type="password" class="form-control" id="password" />
    </div>

    <div class="text-center mt-3">
        <button type="button" id="btnConnexion" class="btn btn-success">Se connecter</button>
        <input type="radio" name="genre" value=femme checked> femme
        <input type="radio" name="genre" value=homme> homme
    </div>
</form>