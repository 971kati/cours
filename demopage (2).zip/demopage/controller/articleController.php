<?php
$articles = new Article();
$articleList = $articles->getArticleList();
$nb = $articles->countArticles();
