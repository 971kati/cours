<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="/css/cyber.css">
    <title>Formulaire de Paiement</title>

</head>

<body>
    <header>
        <h1 class="titre">Cyber-Snack</h1>
        <nav>
            <div class="section-flex">
                <div class="flex-nav nav-3">
                    <img class="logo" src="/Logo Ultimate Corporate.jpg" alt="/Logo Ultimate Corporate.jpg" />
                </div>
            </div>
            <ul class="list-item">
                <li class="item"><a href="#accueil">Accueil</a></li>
                <li class="item"><a href="#services">Services</a></li>
                <li class="item-"><a href="#tarifs">Tarifs</a></li>
                <li class="item"><a href="#reservation">Réservation</a></li>
                <li class="item"><a href="#contact">Contact</a></li>
                <li class="item">Mon Compte <span>&#9660;</span>
                    <ul class="sous-list">
                        <li class="item-sous-list"><a href="inscription.html">inscription</a></li>
                        <li class="item-sous-list"><a href="indentification.html">Identification</a></li>
                        <li class="item-sous-list"><a href="reservation.html">Réservation</a></li>
                        <li class="item-sous-list"><a href="paie.html">Paiement</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <h1>Formulaire de Paiement</h1>
        <form action="traitement_paiement.php" method="post">
            <label for="numero_carte">Numéro de carte de crédit :</label>
            <input type="text" id="numero_carte" name="numero_carte" required>

            <label for="date_expiration">Date d'expiration :</label>
            <input type="text" id="date_expiration" name="date_expiration" placeholder="MM/AA" required>

            <label for="nom_titulaire">Nom du titulaire :</label>
            <input type="text" id="nom_titulaire" name="nom_titulaire" required>

            <label for="cvv">CVV :</label>
            <input type="text" id="cvv" name="cvv" required>

            <button type="submit">Valider le Paiement</button>
        </form>
    </div>
</body>

</html>