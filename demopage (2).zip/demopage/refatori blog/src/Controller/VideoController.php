<?php

namespace App\src\Controller;


use App\Entity\Video;
use App\src\Controller\TwigController;
class VideoController extends TwigController
{
  public function index()
 {
   $Video = new Video;
   $Videos = $Video->getVideos();
   echo $this->twig->render("video/index.html.twig", [
    'Videos' => $Videos,
    'data' => 'Bienvenue sur le controller Video'
  ]);
  }

   public function view($params)
   {
   $getVideo = new Video;
  $getVideo->id = $params;
  // Renvoi un tableau (OBJ) d'une ligne = FETCH
  $Video = $getVideo->getVideoById();
  var_dump($Video);
  echo $this->twig->render("video/index.html.twig", [
  'liveVideo' => $Video,
  'params' => $params,
 'data' => 'Bienvenue sur le controller Video/view'
  ]);
  }
}