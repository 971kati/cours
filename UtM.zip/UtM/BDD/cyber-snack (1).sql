-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 17 jan. 2024 à 09:15
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `cyber-snack`
--

-- --------------------------------------------------------

--
-- Structure de la table `achatssnacks`
--

CREATE TABLE `achatssnacks` (
  `IDAchat` int(11) NOT NULL,
  `IDJoueur` int(11) DEFAULT NULL,
  `IDSnack` int(11) DEFAULT NULL,
  `Quantite` int(11) DEFAULT NULL,
  `DateAchat` date DEFAULT NULL,
  `IDModePaiement` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `ajax_user`
--

CREATE TABLE `ajax_user` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `token` varchar(255) NOT NULL,
  `role` varchar(5) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `Nom` varchar(50) NOT NULL,
  `Prenom` varchar(50) NOT NULL,
  `Adresse` varchar(50) NOT NULL,
  `Tel` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Date-d-Incription` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `cybergamer`
--

CREATE TABLE `cybergamer` (
  `id` int(11) NOT NULL,
  `nom_jeu` varchar(50) DEFAULT NULL,
  `plateforme` varchar(20) DEFAULT NULL,
  `prix` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `cybersnack`
--

CREATE TABLE `cybersnack` (
  `id` int(11) NOT NULL,
  `nom_produit` varchar(50) DEFAULT NULL,
  `prix` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `employer`
--

CREATE TABLE `employer` (
  `id` int(11) NOT NULL,
  `Nom` varchar(50) NOT NULL,
  `Prenom` varchar(30) NOT NULL,
  `Adresse` varchar(40) NOT NULL,
  `Tel` int(11) NOT NULL,
  `DateNaissance` date NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Photo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `historique`
--

CREATE TABLE `historique` (
  `id-Historique` int(11) NOT NULL,
  `id-client` varchar(50) NOT NULL,
  `id-session` int(50) NOT NULL,
  `Action-Effectuees` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `jeux`
--

CREATE TABLE `jeux` (
  `IDJeu` int(11) NOT NULL,
  `NomJeu` varchar(50) DEFAULT NULL,
  `Plateforme` varchar(20) DEFAULT NULL,
  `DateSortie` date DEFAULT NULL,
  `Genre` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `joueurs`
--

CREATE TABLE `joueurs` (
  `IDJoueur` int(11) NOT NULL,
  `Nom` varchar(50) DEFAULT NULL,
  `Prenom` varchar(50) DEFAULT NULL,
  `Pseudo` varchar(30) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `DateNaissance` date DEFAULT NULL,
  `Score` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `modespaiement`
--

CREATE TABLE `modespaiement` (
  `IDModePaiement` int(11) NOT NULL,
  `NomModePaiement` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `oprération`
--

CREATE TABLE `oprération` (
  `id-Transation` int(11) NOT NULL,
  `id-Client` varchar(50) NOT NULL,
  `Date-Heure-Transation` int(11) NOT NULL,
  `Montant-transation` int(11) NOT NULL,
  `Mode-paiement` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `ordinateur`
--

CREATE TABLE `ordinateur` (
  `id` int(11) NOT NULL,
  `Nom-ordinateur` varchar(50) NOT NULL,
  `Etat` varchar(50) NOT NULL,
  `Configuation-Marterielle` varchar(50) NOT NULL,
  `Adress-IP` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `paiement`
--

CREATE TABLE `paiement` (
  `id` int(11) NOT NULL,
  `nom_client` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `produit_achete` varchar(50) DEFAULT NULL,
  `montant` decimal(10,2) DEFAULT NULL,
  `mode_paiement` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `participation`
--

CREATE TABLE `participation` (
  `IDParticipation` int(11) NOT NULL,
  `IDJoueur` int(11) DEFAULT NULL,
  `IDJeu` int(11) DEFAULT NULL,
  `DateParticipation` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `seances`
--

CREATE TABLE `seances` (
  `id-Session` int(11) NOT NULL,
  `id-Cilent` varchar(50) NOT NULL,
  `id-Ordinateur` varchar(50) NOT NULL,
  `Date-Heure-Debut` date NOT NULL,
  `Date-Heure-Fin` date NOT NULL,
  `Coute-Seance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `service`
--

CREATE TABLE `service` (
  `id` int(11) NOT NULL,
  `Speudo` varchar(50) NOT NULL,
  `Tarif` int(11) NOT NULL,
  `Heure` int(11) NOT NULL,
  `Ordinateur` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `snacks`
--

CREATE TABLE `snacks` (
  `IDSnack` int(11) NOT NULL,
  `NomSnack` varchar(50) DEFAULT NULL,
  `TypeSnack` varchar(30) DEFAULT NULL,
  `Prix` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `tarifs`
--

CREATE TABLE `tarifs` (
  `id-Tarif` int(11) NOT NULL,
  `id-client` varchar(50) NOT NULL,
  `id-Session` varchar(50) NOT NULL,
  `Action-effectuee` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Mpd` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `achatssnacks`
--
ALTER TABLE `achatssnacks`
  ADD PRIMARY KEY (`IDAchat`),
  ADD KEY `IDJoueur` (`IDJoueur`),
  ADD KEY `IDSnack` (`IDSnack`),
  ADD KEY `IDModePaiement` (`IDModePaiement`);

--
-- Index pour la table `ajax_user`
--
ALTER TABLE `ajax_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Index pour la table `cybergamer`
--
ALTER TABLE `cybergamer`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `cybersnack`
--
ALTER TABLE `cybersnack`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `jeux`
--
ALTER TABLE `jeux`
  ADD PRIMARY KEY (`IDJeu`);

--
-- Index pour la table `joueurs`
--
ALTER TABLE `joueurs`
  ADD PRIMARY KEY (`IDJoueur`),
  ADD UNIQUE KEY `Pseudo` (`Pseudo`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Index pour la table `modespaiement`
--
ALTER TABLE `modespaiement`
  ADD PRIMARY KEY (`IDModePaiement`);

--
-- Index pour la table `paiement`
--
ALTER TABLE `paiement`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `participation`
--
ALTER TABLE `participation`
  ADD PRIMARY KEY (`IDParticipation`),
  ADD KEY `IDJoueur` (`IDJoueur`),
  ADD KEY `IDJeu` (`IDJeu`);

--
-- Index pour la table `snacks`
--
ALTER TABLE `snacks`
  ADD PRIMARY KEY (`IDSnack`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `ajax_user`
--
ALTER TABLE `ajax_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `cybergamer`
--
ALTER TABLE `cybergamer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `cybersnack`
--
ALTER TABLE `cybersnack`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `paiement`
--
ALTER TABLE `paiement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `achatssnacks`
--
ALTER TABLE `achatssnacks`
  ADD CONSTRAINT `achatssnacks_ibfk_1` FOREIGN KEY (`IDJoueur`) REFERENCES `joueurs` (`IDJoueur`),
  ADD CONSTRAINT `achatssnacks_ibfk_2` FOREIGN KEY (`IDSnack`) REFERENCES `snacks` (`IDSnack`),
  ADD CONSTRAINT `achatssnacks_ibfk_3` FOREIGN KEY (`IDModePaiement`) REFERENCES `modespaiement` (`IDModePaiement`);

--
-- Contraintes pour la table `participation`
--
ALTER TABLE `participation`
  ADD CONSTRAINT `participation_ibfk_1` FOREIGN KEY (`IDJoueur`) REFERENCES `joueurs` (`IDJoueur`),
  ADD CONSTRAINT `participation_ibfk_2` FOREIGN KEY (`IDJeu`) REFERENCES `jeux` (`IDJeu`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
