<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tarifs</title>

    <!-- Ajoutez le lien vers la feuille de style Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>

<section id="tarifs" class="section-flex">
        <h2>Tarifs</h2>
          <table>
              <tr>
                 <th>temps</th>
                 <th>Tarif</th>
              </tr>
              <tr>
               <td>Tarif horaire</td>
                  <td>5 €</td>
              </tr>
              <tr>
               <td>Forfait journée</td>
                  <td>20 €</td>
              </tr>
              <tr>
                   <td>Forfait mensuel</td>
                   <td>100 €</td>
              </tr>
          </table>
      </section>

<!-- Ajoutez le lien vers le script Bootstrap (facultatif si vous utilisez des composants JavaScript) -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
