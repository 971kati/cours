<?php
// Connexion à la base de données (exemple avec MySQL)
$servername = "localhost"; // Adresse du serveur de base de données
$username = "votre_nom_utilisateur"; // Nom d'utilisateur de la base de données
$password = "votre_mot_de_passe"; // Mot de passe de la base de données
$dbname = "votre_base_de_donnees"; // Nom de la base de données

// Créez une connexion à la base de données
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérification de la connexion à la base de données
if ($conn->connect_error) {
    die("La connexion à la base de données a échoué : " . $conn->connect_error);
}

// Récupération des données du formulaire
$nom = $_POST['nom'];
$date = $_POST['date'];
$heure = $_POST['heure'];

// Insérez les données de réservation dans la base de données
$sql = "INSERT INTO reservations (nom, date, heure) VALUES ('$nom', '$date', '$heure')";

if ($conn->query($sql) === TRUE) {
    echo "Réservation enregistrée avec succès!";
} else {
    echo "Erreur lors de l'enregistrement de la réservation : " . $conn->error;
}

// Fermez la connexion à la base de données
$conn->close();
?>
