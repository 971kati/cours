<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nos Services</title>
    <!-- Ajoutez vos liens vers les feuilles de style et scripts nécessaires ici -->
</head>
<body>

<h2>Nos Services</h2>

<?php
// Données des services sous forme de chaîne de caractères
$servicesData = "Connexion Internet haut débit*
*Impression et numérisation*
*Café et collations<*
<!-- Ajoutez d'autres services ici -->";

// Divisez la chaîne en un tableau en utilisant '*' comme séparateur
$servicesArray = explode('*', $servicesData);

// Parcourez le tableau et affichez chaque service
foreach ($servicesArray as $service) {
    // Ignorez les éléments vides (résultant de la séparation)
    if (!empty(trim($service))) {
        echo '<p>' . htmlspecialchars(trim($service)) . '</p>';
    }
}
?>

</body>
</html>
