<?php

namespace App\src\Controller;

use App\Entity\Portfolio;
use App\src\Controller\TwigController;
class PortfolioController extends TwigController
{
    public function index()
    {
        $portfolio = new Portfolio;
        $items = $portfolio->getPortfolioItems();
        echo $this->twig->render("portfolio/index.html.twig", [
            'items' => $items,
            'data' => 'Bienvenue sur le controller Portfolio'
        ]);
    }

    public function view($params)
    {
        $getPortfolioItem = new Portfolio;
        $getPortfolioItem->id = $params;
        // Renvoi un tableau (OBJ) d'une ligne = FETCH
        $portfolioItem = $getPortfolioItem->getPortfolioItemById();
        var_dump($portfolioItem);
        echo $this->twig->render("portfolio/index.html.twig", [
            'portfolioItem' => $portfolioItem,
            'params' => $params,
            'data' => 'Bienvenue sur le controller Portfolio/view'
        ]);
    }
}/