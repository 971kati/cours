<?php
define("HOST", "localhost");
define("DBNAME", "");
define("LOGIN", "root"); //identifiant mysql
define("PASSWORD", ""); //password mysql