<?php
  $con = mysqli_connect("localhost","root","","cyber-snack");
  if(!$con){
     echo "Vous n'êtes pas connecté à la base de donnée";
  }
?>