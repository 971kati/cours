<?php
// src/Entity/Portfolio.php

// src/Entity/Portfolio.php

namespace App\Entity;

use App\src\Entity\Database;
use PDO;
use Exception;

class Portfolio
{
    private $id;
    private $title;
    private $imageUrl;

    public function __construct($title, $imageUrl)
    {
        $this->title = $title;
        $this->imageUrl = $imageUrl;
    }

    // Getter et Setter pour l'ID
    public function getId()
    {
        return $this->id;
    }

    // Getter et Setter pour le titre
    public function getTitle()
    {
        return $this->title;
    }

    public function setTitle($title)
    {
        $this->title = $title;
    }

    // Getter et Setter pour l'URL de l'image
    public function getImageUrl()
    {
        return $this->imageUrl;
    }

    public function setImageUrl($imageUrl)
    {
        $this->imageUrl = $imageUrl;
    }

    // Méthode pour enregistrer le portfolio en base de données
    public function save()
    {
        try {
            $pdo = new PDO('mysql:host=' . HOST . ';dbname=' . DBNAME, LOGIN, PASSWORD);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $stmt = $pdo->prepare('INSERT INTO portfolio (titre, image_url) VALUES (?, ?)');
            $stmt->execute([$this->title, $this->imageUrl]);

            $this->id = $pdo->lastInsertId();
        } catch (Exception $e) {
            echo 'Erreur : ' . $e->getMessage();
        }
    }
}