<?php

namespace App\src\Controller;

use App\src\Entity\Article;
use App\src\Controller\TwigController;

class LiveVideoController extends TwigController
{
    public function index()
    {
        $liveVideo = new LiveVideo;
        $liveVideos = $liveVideo->getLiveVideos();
        echo $this->twig->render("livevideo/index.html.twig", [
            'liveVideos' => $liveVideos,
            'data' => 'Bienvenue sur le controller LiveVideo'
        ]);
    }

    public function view($params)
    {
        $getLiveVideo = new LiveVideo;
        $getLiveVideo->id = $params;
        // Renvoi un tableau (OBJ) d'une ligne = FETCH
        $liveVideo = $getLiveVideo->getLiveVideoById();
        var_dump($liveVideo);
        echo $this->twig->render("livevideo/index.html.twig", [
            'liveVideo' => $liveVideo,
            'params' => $params,
            'data' => 'Bienvenue sur le controller LiveVideo/view'
        ]);
    }
}